package batalhanaval;

public class Main 
{
    public static void main(String[] args)
    {
       BatalhaNaval b = new BatalhaNaval();  
    }
}
